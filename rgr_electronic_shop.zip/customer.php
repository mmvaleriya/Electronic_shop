<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset="utf-8">
<title>Customers</title>
<link rel="stylesheet" type="text/css" href="table_style.css">
</head>
<body>
<?php
$connection = new mysqli("localhost", "root","youcandoit09","electronicshop");
if($connection->connect_error){
    die("Error: " . $connection->connect_error);
}
function getPostsCust()
			{
			    $postsCust = array();
			    $postsCust[1] = $_POST['id_cst'];
			    $postsCust[2] = $_POST['name_cst'];
			    $postsCust[3] = $_POST['email'];
				$postsCust[4] = $_POST['login'];
				$postsCust[5] = $_POST['phone'];
				$postsCust[6] = $_POST['id_sl'];
			    return $postsCust;
			}
			$sql = "SELECT * FROM customer ORDER BY 'ASC' ";

				if (!$result = mysqli_query($connection, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '6'>Customers</tr></th></thead>\n";
				while ($customer = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $customer['id_cst'] . "</td><td>". $customer['name_cst'] . "</td><td>" . $customer['email'] . "</td><td>" . $customer['login']. "</td><td>" . $customer['phone']. "</td><td>" . $customer['id_sl']. "</td>" ;
				    echo "</tr>";
				}

			echo "</table>\n";

			if(isset($_POST['add']))
			{
			    $data = getPostsCust();
				$var_email = $_POST['email'];
                     if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                           echo "Email is correct!";
                        } else {
                          echo "Warning! Email is`nt correct!\n";
                        }
						$sanitized_email= filter_var($var_email, FILTER_SANITIZE_EMAIL);
						if (filter_var($sanitized_email, FILTER_VALIDATE_EMAIL)) {
                        echo "Maybe, you mean this:\n";
                        echo "$sanitized_email\n";
}
			    $insert_Query = "INSERT INTO `customer`(`id_cst`, `name_cst`, `email`, `login`, `phone`, `id_sl`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]')";
			    try{
			        $insert_Result = mysqli_query($connection, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Added!';
			            }else{
			                echo 'Not added!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}

			if(isset($_POST['delete']))
			{
			    $data = getPostsCust();
			    $delete_Query = "DELETE FROM `customer` WHERE `id_cst` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($connection, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Deleted!';
			            }else{
			                echo 'Not deleted!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}


			if(isset($_POST['update']))
			{
			    $data = getPostsCust();
			    $update_Query = "UPDATE `customer` SET `id_cst`='$data[1]',`name_cst`='$data[2]',`email`='$data[3]',`login`='$data[4]', `phone`='$data[5]' , `id_sl`='$data[6]' WHERE `id_cst` = '$data[0]'";
			    try{
			        $update_Result = mysqli_query($connection, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No Updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="customer.php" method="post"><br><br>
		<input type="number" name = "id_cst" placeholder = "id" value="<?php echo $id_cst;?>"><br><br>
		<input type="text" name = "name_cst" placeholder = "name" value="<?php echo $name_cst;?>"><br><br>
		<input type="text" name = "email" placeholder = "email" value="<?php echo $email;?>"><br><br>
		<input type="text" name = "login" placeholder = "login" value="<?php echo $login;?>"><br><br>
		<input type="text" name = "phone" placeholder = "phone" value="<?php echo $phone;?>"><br><br>
		<input type="number" name = "id_sl" placeholder = "seller`s id" value="<?php echo $id_sl;?>"><br><br>
		
		<div>
		    <input type="submit" name = "add" value="Add">
			<input type="submit" name = "delete" value="Delete">
			<input type="submit" name = "update" value="Update">
		</div>
	</form>
</html>