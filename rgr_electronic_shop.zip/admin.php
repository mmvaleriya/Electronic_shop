<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset="utf-8">
<title>Admins</title>
<link rel="stylesheet" type="text/css" href="table_style.css">
</head>
<body>
<?php
$connection = new mysqli("localhost", "root","youcandoit09","electronicshop");
if($connection->connect_error){
    die("Error: " . $connection->connect_error);
}
function getPostsAdm()
			{
			    $postsAdm = array();
			    $postsAdm[1] = $_POST['id_adm'];
			    $postsAdm[2] = $_POST['name_adm'];
			    $postsAdm[3] = $_POST['workexperience_adm'];
				$postsAdm[4] = $_POST['salary_adm'];
			    return $postsAdm;
			}
			$sql = "SELECT * FROM admin ORDER BY 'ASC' ";

				if (!$result = mysqli_query($connection, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '4'>Admins</tr></th></thead>\n";
				while ($admin = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $admin['id_adm'] . "</td><td>". $admin['name_adm'] . "</td><td>" . $admin['workexperience_adm'] . "</td><td>" . $admin['salary_adm']. "</td>" ;
				    echo "</tr>";
				}

			echo "</table>\n";

			if(isset($_POST['add']))
			{
			    $data = getPostsAdm();
			    $insert_Query = "INSERT INTO `admin`(`id_adm`, `name_adm`, `workexperience_adm`, `salary_adm`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]')";
			    try{
			        $insert_Result = mysqli_query($connection, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Added!';
			            }else{
			                echo 'Not added!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}

			if(isset($_POST['delete']))
			{
			    $data = getPostsAdm();
			    $delete_Query = "DELETE FROM `admin` WHERE `id_adm` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($connection, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Deleted!';
			            }else{
			                echo 'Not deleted!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}


			if(isset($_POST['update']))
			{
			    $data = getPostsAdm();
			    $update_Query = "UPDATE `admin` SET `id_adm`='$data[1]',`name_adm`='$data[2]',`workexperience_adm`='$data[3]',`salary_adm`='$data[4]'  WHERE `id_adm` = '$data[0]'";
			    try{
			        $update_Result = mysqli_query($connection, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No Updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="admin.php" method="post"><br><br>
		<input type="number" name = "id_adm" placeholder = "id" value="<?php echo $id_adm;?>"><br><br>
		<input type="text" name = "name_adm" placeholder = "name" value="<?php echo $name_adm;?>"><br><br>
		<input type="number" name = "workexperience_adm" placeholder = "work experience" value="<?php echo $workexperience_adm;?>"><br><br>
		<input type="number" name = "salary_adm" placeholder = "salary" value="<?php echo $salary_adm;?>"><br><br>
		
		<div>
		    <input type="submit" name = "add" value="Add">
			<input type="submit" name = "delete" value="Delete">
			<input type="submit" name = "update" value="Update">
		</div>
	</form>
</html>