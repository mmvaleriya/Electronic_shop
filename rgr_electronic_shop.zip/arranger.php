<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset="utf-8">
<title>Arrangers</title>
<link rel="stylesheet" type="text/css" href="table_style.css">
</head>
<body>
<?php
$connection = new mysqli("localhost", "root","youcandoit09","electronicshop");
if($connection->connect_error){
    die("Error: " . $connection->connect_error);
}
function getPostsArr()
			{
			    $postsArr = array();
			    $postsArr[1] = $_POST['id_arr'];
			    $postsArr[2] = $_POST['name_arr'];
			    $postsArr[3] = $_POST['workexperience_arr'];
				$postsArr[4] = $_POST['salary_arr'];
				$postsArr[5] = $_POST['id_adm'];
			    return $postsArr;
			}
			$sql = "SELECT * FROM arranger ORDER BY 'ASC' ";

				if (!$result = mysqli_query($connection, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '5'>Arrangers</tr></th></thead>\n";
				while ($arranger = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $arranger['id_arr'] . "</td><td>". $arranger['name_arr'] . "</td><td>" . $arranger['workexperience_arr'] . "</td><td>" . $arranger['salary_arr']. "</td><td>" . $arranger['id_adm']. "</td>" ;
				    echo "</tr>";
				}

			echo "</table>\n";

			if(isset($_POST['add']))
			{
			    $data = getPostsArr();
			    $insert_Query = "INSERT INTO `arranger`(`id_arr`, `name_arr`, `workexperience_arr`, `salary_arr`, `id_adm`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]')";
			    try{
			        $insert_Result = mysqli_query($connection, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Added!';
			            }else{
			                echo 'Not added!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}

			if(isset($_POST['delete']))
			{
			    $data = getPostsArr();
			    $delete_Query = "DELETE FROM `arranger` WHERE `id_arr` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($connection, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Deleted!';
			            }else{
			                echo 'Not deleted!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}


			if(isset($_POST['update']))
			{
			    $data = getPostsArr();
			    $update_Query = "UPDATE `arranger` SET `id_arr`='$data[1]',`name_arr`='$data[2]',`workexperience_arr`='$data[3]',`salary_arr`='$data[4]', `id_adm`='$data[5]'  WHERE `id_arr` = '$data[0]'";
			    try{
			        $update_Result = mysqli_query($connection, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No Updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="arranger.php" method="post"><br><br>
		<input type="number" name = "id_arr" placeholder = "id" value="<?php echo $id_arr;?>"><br><br>
		<input type="text" name = "name_arr" placeholder = "name" value="<?php echo $name_arr;?>"><br><br>
		<input type="number" name = "workexperience_arr" placeholder = "work experience" value="<?php echo $workexperience_arr;?>"><br><br>
		<input type="number" name = "salary_arr" placeholder = "salary" value="<?php echo $salary_arr;?>"><br><br>
		<input type="number" name = "id_adm" placeholder = "admin`s id" value="<?php echo $id_adm;?>"><br><br>
		
		<div>
		    <input type="submit" name = "add" value="Add">
			<input type="submit" name = "delete" value="Delete">
			<input type="submit" name = "update" value="Update">
		</div>
	</form>
</html>