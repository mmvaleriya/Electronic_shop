<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset="utf-8">
<title>Goods</title>
<link rel="stylesheet" type="text/css" href="table_style.css">
</head>
<body>
<?php
$connection = new mysqli("localhost", "root","youcandoit09","electronicshop");
if($connection->connect_error){
    die("Error: " . $connection->connect_error);
}
function getPostsGd()
			{
			    $postsGd = array();
			    $postsGd[1] = $_POST['id_gd'];
			    $postsGd[2] = $_POST['name_gd'];
			    $postsGd[3] = $_POST['type'];
				$postsGd[4] = $_POST['cost'];
				$postsGd[5] = $_POST['age'];
				$postsGd[6] = $_POST['delivery_data'];
				$postsGd[7] = $_POST['id_arr'];
				$postsGd[8] = $_POST['id_sl'];
				$postsGd[9] = $_POST['id_cst'];
			    return $postsGd;
			}
			$sql = "SELECT * FROM goods ORDER BY 'ASC' ";

				if (!$result = mysqli_query($connection, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '9'>Goods</tr></th></thead>\n";
				while ($goods = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $goods['id_gd'] . "</td><td>". $goods['name_gd'] . "</td><td>" . $goods['type'] . "</td><td>" . $goods['cost']. "</td><td>" . $goods['age']. "</td><td>" . $goods['delivery_data']. "</td><td>" . $goods['id_arr']. "</td><td>" . $goods['id_sl']. "</td><td>" . $goods['id_cst']. "</td>" ;
				    echo "</tr>";
				}

			echo "</table>\n";

			if(isset($_POST['add']))
			{
			    $data = getPostsGd();
			    $insert_Query = "INSERT INTO `goods`(`id_gd`, `name_gd`, `type`, `cost`, `age`, `delivery_data`, `id_arr`, `id_sl`, `id_cst`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]','$data[9]')";
			    try{
			        $insert_Result = mysqli_query($connection, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Added!';
			            }else{
			                echo 'Not added!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}

			if(isset($_POST['delete']))
			{
			    $data = getPostsGd();
			    $delete_Query = "DELETE FROM `goods` WHERE `id_gd` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($connection, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Deleted!';
			            }else{
			                echo 'Not deleted!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}


			if(isset($_POST['update']))
			{
			    $data = getPostsGd();
			    $update_Query = "UPDATE `goods` SET `id_gd`='$data[1]',`name_gd`='$data[2]',`type`='$data[3]',`cost`='$data[4]', `age`='$data[5]' , `delivery_data`='$data[6]', `id_arr`='$data[7]', `id_sl`='$data[8]', `id_cst`='$data[9]' WHERE `id_gd` = '$data[0]'";
			    try{
			        $update_Result = mysqli_query($connection, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No Updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="goods.php" method="post"><br><br>
		<input type="number" name = "id_gd" placeholder = "id" value="<?php echo $id_gd;?>"><br><br>
		<input type="text" name = "name_gd" placeholder = "name" value="<?php echo $name_gd;?>"><br><br>
		<input type="text" name = "type" placeholder = "type" value="<?php echo $type;?>"><br><br>
		<input type="number" name = "cost" placeholder = "cost" value="<?php echo $cost;?>"><br><br>
		<input type="number" name = "age" placeholder = "age" value="<?php echo $age;?>"><br><br>
		<input type="datetime-local" name = "delivery_data" placeholder = "delivery data" value="<?php echo $delivery_data;?>"><br><br>
		<input type="number" name = "id_arr" placeholder = "arranger`s id" value="<?php echo $id_arr;?>"><br><br>
		<input type="number" name = "id_sl" placeholder = "seller`s id" value="<?php echo $id_sl;?>"><br><br>
		<input type="number" name = "id_cst" placeholder = " customer`s id" value="<?php echo $id_cst;?>"><br><br>
		
		<div>
		    <input type="submit" name = "add" value="Add">
			<input type="submit" name = "delete" value="Delete">
			<input type="submit" name = "update" value="Update">
		</div>
	</form>
</html>