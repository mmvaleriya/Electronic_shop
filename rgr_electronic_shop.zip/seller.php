<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset="utf-8">
<title>Sellers</title>
<link rel="stylesheet" type="text/css" href="table_style.css">
</head>
<body>
<?php
$connection = new mysqli("localhost", "root","youcandoit09","electronicshop");
if($connection->connect_error){
    die("Error: " . $connection->connect_error);
}
function getPostsSell()
			{
			    $postsSell = array();
			    $postsSell[1] = $_POST['id_sl'];
			    $postsSell[2] = $_POST['name_sl'];
			    $postsSell[3] = $_POST['workexperience_sl'];
				$postsSell[4] = $_POST['salary_sl'];
				$postsSell[5] = $_POST['id_adm'];
			    return $postsSell;
			}
			$sql = "SELECT * FROM seller ORDER BY 'ASC' ";

				if (!$result = mysqli_query($connection, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '5'>Sellers</tr></th></thead>\n";
				while ($seller = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $seller['id_sl'] . "</td><td>". $seller['name_sl'] . "</td><td>" . $seller['workexperience_sl'] . "</td><td>" . $seller['salary_sl']. "</td><td>" . $seller['id_adm']. "</td>" ;
				    echo "</tr>";
				}

			echo "</table>\n";

			if(isset($_POST['add']))
			{
			    $data = getPostsSell();
			    $insert_Query = "INSERT INTO `seller`(`id_sl`, `name_sl`, `workexperience_sl`, `salary_sl`, `id_adm`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]')";
			    try{
			        $insert_Result = mysqli_query($connection, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Added!';
			            }else{
			                echo 'Not added!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}

			if(isset($_POST['delete']))
			{
			    $data = getPostsSell();
			    $delete_Query = "DELETE FROM `seller` WHERE `id_sl` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($connection, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Deleted!';
			            }else{
			                echo 'Not deleted!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}


			if(isset($_POST['update']))
			{
			    $data = getPostsSell();
			    $update_Query = "UPDATE `seller` SET `id_sl`='$data[1]',`name_sl`='$data[2]',`workexperience_sl`='$data[3]',`salary_sl`='$data[4]', `id_adm`='$data[5]'  WHERE `id_sl` = '$data[0]'";
			    try{
			        $update_Result = mysqli_query($connection, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($connection) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No Updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="seller.php" method="post"><br><br>
		<input type="number" name = "id_sl" placeholder = "id" value="<?php echo $id_sl;?>"><br><br>
		<input type="text" name = "name_sl" placeholder = "name" value="<?php echo $name_sl;?>"><br><br>
		<input type="number" name = "workexperience_sl" placeholder = "work experience" value="<?php echo $workexperience_sl;?>"><br><br>
		<input type="number" name = "salary_sl" placeholder = "salary" value="<?php echo $salary_sl;?>"><br><br>
		<input type="number" name = "id_adm" placeholder = "admin`s id" value="<?php echo $id_adm;?>"><br><br>
		
		<div>
		    <input type="submit" name = "add" value="Add">
			<input type="submit" name = "delete" value="Delete">
			<input type="submit" name = "update" value="Update">
		</div>
	</form>
</html>