<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>People</title>
<link rel="stylesheet" type="text/css" href="electric_style.css">
</head>
<body>
<?php
$connection = new mysqli("localhost", "root","youcandoit09","electronicshop");
if($connection->connect_error){
    die("Error: " . $connection->connect_error);
}
?>

</body>
<h2> Choose a page: </h2>

	<div>
<button onclick="window.location.href = 'customer.php';">Customers</button>
<button onclick="window.location.href = 'seller.php';" >Sellers</button>
<button onclick="window.location.href = 'manager.php';">Managers</button>
<button onclick="window.location.href = 'arranger.php';">Arrangers</button>
<button onclick="window.location.href = 'admin.php';">Admins</button>		
		</div>
</html>