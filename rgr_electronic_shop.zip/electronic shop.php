<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Electronic Shop</title>
<link rel="stylesheet" type="text/css" href="electric_style.css">
</head>
<body>
<?php
$connection = new mysqli("localhost", "root","youcandoit09","electronicshop");
if($connection->connect_error){
    die("Error: " . $connection->connect_error);
}
echo "Database was connected!";
?>
</body>
<h1>Database of Electronic Shop</h1>
<h3> Choose a page: </h3>
<div>
<button onclick="window.location.href = 'people.php';">People</button>
<button onclick="window.location.href = 'goods.php';" >Goods</button>
</div>
</html>